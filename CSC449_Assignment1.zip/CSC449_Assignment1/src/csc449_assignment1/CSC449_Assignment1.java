package csc449_assignment1;
import java.util.Scanner; 
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
public class CSC449_Assignment1 {
    public static void main(String[] args) {
        try {
            FileReader sort = new FileReader("Sort_Me.txt");
            Scanner file = new Scanner(sort);
            List<String> Names=new ArrayList<>();
            while( file.hasNextLine() ) {
                Names.add(file.nextLine());
            }
            Names.sort(Comparator.comparing(String::length).thenComparing(String::compareTo));

        System.out.println(Names);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(CSC449_Assignment1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
